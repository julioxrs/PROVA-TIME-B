
package br.ceuma.agendamento.bean;

import br.ceuma.agendamento.dao.HorarioDAO;
import br.ceuma.agendamento.modelo.Horario;
import br.ceuma.agendamento.sessao.SessionContext;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;

@ViewScoped
@ManagedBean
public class HorarioBean {
    
    //@ManagedProperty(value = "#{horarioDAO}")
    private HorarioDAO horarioDAO = new HorarioDAO();
        
    private List<Horario> horarios = new ArrayList<>();
    
    private Horario horarioSelecionado = new Horario();

    public HorarioBean(){
        listar();
    }
     
    //@PostConstruct
    public void listar(){
        horarios = horarioDAO.buscarDisponiveisAtuais();
        //horarios = horarioDAO.buscarDisponiveis();
    }

    public List<Horario> getHorarios() {
        listar();// para realizar atualização da tabela de horarios sempre que houver alteração
        return horarios;
    }

    public void setHorarios(List<Horario> horarios) {
        this.horarios = horarios;
    }

    public HorarioDAO getHorarioDAO() {
        return horarioDAO;
    }

    public void setHorarioDAO(HorarioDAO horarioDAO) {
        this.horarioDAO = horarioDAO;
    }

    public Horario getHorarioSelecionado() {        
        //return horarioSelecionado;
        return (Horario) SessionContext.getInstancia().getAtributo("horarioSelecionado");
    }

    // salva o horario selecionado no Map da sessão
    public void setHorarioSelecionado(Horario horarioSelecionado) {
        SessionContext.getInstancia().setAtributo("horarioSelecionado", horarioSelecionado);
        this.horarioSelecionado = horarioSelecionado;
    }
    
    
    
}
