package br.ceuma.agendamento.sessao;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class FiltraPagina implements Filter {

    @Override
    public void destroy() {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {

        // recupera sessão atual ou cria uma caso não exista
        HttpSession sessao = ((HttpServletRequest) request).getSession(true);

        // captura a sessão HttpSession e após, a pagina atual sendo acessada
        String novaPagina = ((HttpServletRequest) request).getServletPath();

        // verifica se não existe uma página atual gravada na sessão        
        if (sessao.getAttribute("currentPage") == null) {
            //primeiro acesso do usuário
            // grava a pagina atual e a anterior como sendo as mesmas
            sessao.setAttribute("lastPage", novaPagina);
            sessao.setAttribute("currentPage", novaPagina);
        } else {

            // verifica se já houve algum acesso. Neste caso, salva a pagina anterior
            // como pagina anterior e a pagina sendo acessada atualmente, como pagina corrente (atual)
            String antigaPagina = sessao.getAttribute("currentPage").toString();
            if (!antigaPagina.equals(novaPagina)) {
                sessao.setAttribute("lastPage", antigaPagina);
                sessao.setAttribute("currentPage", novaPagina);
            }
        }

        // permite que o usuário prossiga com o seu fluxo de navegação
        chain.doFilter(request, response);

    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
        
    }

}
