
package br.ceuma.agendamento.sessao;

// usa padrão Singleton (garantido a existencia de apenas um objeto)

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;


// Classe para contexto da sessão
public class ContextoSessao {
    
    private static ContextoSessao instancia;

    public static ContextoSessao getInstancia() {
        if(instancia == null){
            instancia = new ContextoSessao();
        }
        
        return instancia;
    }
    
    private ContextoSessao(){
        
    }
    
    private ExternalContext currenExternalContext(){
        if(FacesContext.getCurrentInstance() == null) //caso o objeto seja chamado fora de uma requisição HTTP
            throw new RuntimeException("O FacesContext não pode ser chamado fora de uma requisição HTTP");
         else 
            return FacesContext.getCurrentInstance().getExternalContext();
    }
    
    public void encerrarSessao(){//utilizado para logout do sistema
        // encerra sessão e faz com que todos os atributos salvos sejam perdidos
        currenExternalContext().invalidateSession();
    }
    
    public Object getAtributo(String nome){
        // recupera, entre os atributos da sessão (obtido por getSessionMap(),
        // o que possui valor setado em 'nome'
        return currenExternalContext().getSessionMap().get(nome);
    }
    
    public void setAtributo(String nome, Object valor){
        // insere um objeto 'valor' no Map da sessão
        currenExternalContext().getSessionMap().put(nome, valor);
    }
    
}
